﻿using System;

public class GetAllPlushToysByToyMakerRequest
{
    public int ToyMakerId { get; set; }
    public DateTime AfterDate { get; set; }
}
